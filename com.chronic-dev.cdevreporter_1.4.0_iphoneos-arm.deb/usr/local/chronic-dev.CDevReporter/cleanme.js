#!/usr/bin/env node 

var cleanHosts = require("./clean.js").clean;

cleanHosts();