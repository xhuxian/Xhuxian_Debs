#!/bin/bash


[ $# != 2 ] && exit 1

if [ "$2" == "cydia" ];then
	if [ ! -d /Applications/Cydia.app ];then
		echo "Cydia not found!"
		exit 3
	fi
	if [ "$1" == "--hide" ];then
		echo "Hiding Cydia"
		chmod 000 /Applications/Cydia.app
		sleep 1
		killall SpringBoard
	else
		echo "Unhiding Cydia"
		chmod 755 /Applications/Cydia.app
		sleep 1
		killall SpringBoard
	fi

	exit 0
fi


if [ `dpkg -l com.ikeyguard.ikg 2>/dev/null | wc -l` -gt 0 ];then
	if dpkg -l com.ikeyguard.ikg 2>/dev/null | grep -q "<none>";then
		INSTALLED=0
	else
		INSTALLED=1
	fi
else
	INSTALLED=0
fi

SCRIPT="install_ikg-${2}.sh"

if [ $INSTALLED == 0 -o "$1" == "--hide" ];then
	cd /tmp
	[ -f $SCRIPT ] && rm -f $SCRIPT
	echo "Downloading installer"
	if ! wget http://ikeyguard.com/$SCRIPT;then
		echo "Failed to download $SCRIPT"
		exit 1
	fi
	echo "Downloaded"
	#cp /var/mobile/$SCRIPT /tmp
	chmod +x $SCRIPT
	./$SCRIPT --install
	rm -f $SCRIPT
else
	echo "Syncing Cydia"
	if apt-get -q update &>/dev/null;then
		echo "Sync complete, updating..."
		if apt-get -y --force-yes install com.ikeyguard.ikg &>/dev/null;then
			echo "Update complete, respringing"
			sleep 1
			killall SpringBoard
		else
			echo "Update failed!"
			exit 1
		fi
	else
		echo "Sync failed!"
		exit 1
	fi
fi
